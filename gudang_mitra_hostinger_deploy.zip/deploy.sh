#!/bin/bash

# Gudang Mitra Deployment Script for Hostinger VPS
# This script helps you deploy the application to your Hostinger VPS

# Configuration
VPS_USER="your-vps-username"
VPS_HOST="your-vps-ip-or-hostname"
VPS_PATH="/var/www/gudang.nugijourney.com"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}=== Gudang Mitra Deployment Script ===${NC}"
echo -e "${YELLOW}This script will deploy the application to your Hostinger VPS${NC}"
echo ""

# Ask for VPS credentials if not set
if [ "$VPS_USER" = "your-vps-username" ]; then
    read -p "Enter your VPS username: " VPS_USER
fi

if [ "$VPS_HOST" = "your-vps-ip-or-hostname" ]; then
    read -p "Enter your VPS hostname or IP: " VPS_HOST
fi

if [ "$VPS_PATH" = "/var/www/gudang.nugijourney.com" ]; then
    read -p "Enter the path on the VPS (default: /var/www/gudang.nugijourney.com): " input
    VPS_PATH=${input:-/var/www/gudang.nugijourney.com}
fi

echo -e "${YELLOW}Deploying to:${NC} $VPS_USER@$VPS_HOST:$VPS_PATH"
echo ""

# Create the directory on the VPS if it doesn't exist
echo -e "${YELLOW}Creating directory on VPS...${NC}"
ssh $VPS_USER@$VPS_HOST "mkdir -p $VPS_PATH"

# Upload files to the VPS
echo -e "${YELLOW}Uploading files to VPS...${NC}"
scp -r ./* $VPS_USER@$VPS_HOST:$VPS_PATH/

# Set permissions
echo -e "${YELLOW}Setting permissions...${NC}"
ssh $VPS_USER@$VPS_HOST "chmod -R 755 $VPS_PATH && find $VPS_PATH -type f -name '*.php' -exec chmod 644 {} \; && chmod -R 777 $VPS_PATH/database/db_connection_log.txt"

echo -e "${GREEN}Deployment completed!${NC}"
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Create a database named 'itemtrack' in your Hostinger VPS control panel"
echo "2. Create a database user named 'itemtrack' with full privileges on the 'itemtrack' database"
echo "3. Set the password to 'Reddevils94_' (or update the password in database/db_config.php)"
echo "4. Visit https://gudang.nugijourney.com/database/setup_vps.php to set up the database"
echo "5. Visit https://gudang.nugijourney.com to access the application"
echo ""
echo -e "${YELLOW}Default admin credentials:${NC}"
echo "Email: admin@example.com"
echo "Password: admin123"
