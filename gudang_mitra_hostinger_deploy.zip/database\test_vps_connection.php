<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Hostinger VPS Database Connection Test</h1>";

// Database configuration
$db_host = 'localhost';
$db_name = 'itemtrack';
$db_user = 'itemtrack';
$db_pass = 'Reddevils94_';

try {
    // Connect to MySQL server
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2 style='color: green;'>Connected to database successfully!</h2>";
    
    // Check if tables exist
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h3>Tables in database:</h3>";
    echo "<ul>";
    foreach ($tables as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>";
    
    // Check if users exist
    $stmt = $pdo->query("SELECT id, name, email, role FROM users LIMIT 5");
    $users = $stmt->fetchAll();
    
    echo "<h3>Sample users:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>";
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($user['id']) . "</td>";
        echo "<td>" . htmlspecialchars($user['name']) . "</td>";
        echo "<td>" . htmlspecialchars($user['email']) . "</td>";
        echo "<td>" . htmlspecialchars($user['role']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check if items exist
    $stmt = $pdo->query("SELECT id, name, category, quantity FROM items LIMIT 5");
    $items = $stmt->fetchAll();
    
    echo "<h3>Sample items:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Category</th><th>Quantity</th></tr>";
    foreach ($items as $item) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['id']) . "</td>";
        echo "<td>" . htmlspecialchars($item['name']) . "</td>";
        echo "<td>" . htmlspecialchars($item['category']) . "</td>";
        echo "<td>" . htmlspecialchars($item['quantity']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p>Database connection and tables are working correctly.</p>";
    echo "<p><a href='../index.html'>Go to the application</a></p>";
    
} catch(PDOException $e) {
    echo "<h2 style='color: red;'>Connection failed:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    
    echo "<h3>Troubleshooting:</h3>";
    echo "<ol>";
    echo "<li>Make sure the database 'itemtrack' exists in your Hostinger VPS</li>";
    echo "<li>Make sure the database user 'itemtrack' exists and has the correct password</li>";
    echo "<li>Make sure the database user has full privileges on the 'itemtrack' database</li>";
    echo "<li>Check if the database server is running</li>";
    echo "</ol>";
}
?>
