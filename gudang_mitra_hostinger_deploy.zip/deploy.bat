@echo off
echo === Gudang Mitra Deployment Script ===
echo This script will help you deploy the application to your Hostinger VPS
echo.

set /p VPS_USER=Enter your VPS username: 
set /p VPS_HOST=Enter your VPS hostname or IP: 
set /p VPS_PATH=Enter the path on the VPS (default: /var/www/gudang.nugijourney.com): 

if "%VPS_PATH%"=="" set VPS_PATH=/var/www/gudang.nugijourney.com

echo.
echo Deploying to: %VPS_USER%@%VPS_HOST%:%VPS_PATH%
echo.

echo Creating directory on VPS...
ssh %VPS_USER%@%VPS_HOST% "mkdir -p %VPS_PATH%"

echo Uploading files to VPS...
scp -r ./* %VPS_USER%@%VPS_HOST%:%VPS_PATH%/

echo Setting permissions...
ssh %VPS_USER%@%VPS_HOST% "chmod -R 755 %VPS_PATH% && find %VPS_PATH% -type f -name '*.php' -exec chmod 644 {} \; && chmod -R 777 %VPS_PATH%/database/db_connection_log.txt"

echo.
echo Deployment completed!
echo.
echo Next steps:
echo 1. Create a database named 'itemtrack' in your Hostinger VPS control panel
echo 2. Create a database user named 'itemtrack' with full privileges on the 'itemtrack' database
echo 3. Set the password to 'Reddevils94_' (or update the password in database/db_config.php)
echo 4. Visit https://gudang.nugijourney.com/database/setup_vps.php to set up the database
echo 5. Visit https://gudang.nugijourney.com to access the application
echo.
echo Default admin credentials:
echo Email: admin@example.com
echo Password: admin123

pause
