# Gudang Mitra - Hostinger VPS Deployment

This directory contains all the files needed to deploy the Gudang Mitra application to a Hostinger VPS.

## Deployment Steps

### 1. Upload Files to VPS

1. Connect to your Hostinger VPS using SFTP or SSH
2. Upload all files and folders from this directory to the web root directory (usually `/var/www/html` or `/var/www/gudang.nugijourney.com`)

### 2. Set Up the Database

1. Create a MySQL database named `itemtrack` in your Hostinger VPS control panel
2. Create a MySQL user named `itemtrack` with full privileges on the `itemtrack` database
3. Set the password to `Reddevils94_` (or update the password in `database/db_config.php` if you use a different one)
4. Visit `https://gudang.nugijourney.com/database/setup_vps.php` to set up the database tables and sample data

### 3. Configure Web Server

#### For Apache (default on Hostinger)

The included `.htaccess` file should handle the necessary configuration for Apache.

#### For Nginx

If you're using Nginx, add the following configuration to your server block:

```nginx
server {
    listen 80;
    server_name gudang.nugijourney.com;
    root /var/www/gudang.nugijourney.com;
    index index.html index.php;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /database {
        try_files $uri $uri/ /database/index.php?$query_string;
        
        location ~ \.php$ {
            include snippets/fastcgi-php.conf;
            fastcgi_pass unix:/var/run/php/php-fpm.sock;
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            include fastcgi_params;
        }
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

### 4. Set Up SSL Certificate

1. In your Hostinger VPS control panel, set up an SSL certificate for your domain
2. Make sure your site is accessible via HTTPS

### 5. Test the Deployment

1. Visit `https://gudang.nugijourney.com` to access the application
2. Log in with the default admin credentials:
   - Email: admin@example.com
   - Password: admin123

## Troubleshooting

If you encounter any issues:

1. Check the database connection in `database/db_config.php`
2. Make sure your Hostinger database user has the correct privileges
3. Check the PHP error logs in your Hostinger VPS
4. Visit `https://gudang.nugijourney.com/database/test_connection.php` to test the database connection
